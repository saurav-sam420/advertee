import React from "react";
import AppRoutes from "./routes/approutes";
import "./App.css"; // Global styles (optional)

function App() {
  return <AppRoutes />;
}

export default App;
